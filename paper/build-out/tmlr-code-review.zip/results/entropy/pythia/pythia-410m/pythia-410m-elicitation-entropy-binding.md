# Model data captured during Entropy Battery

- Model name: pythia-410m
- Model dtype: torch.float32
- Layers: 24
- Heads: 16
- Hidden size: 1024
- Params: 405.3M
