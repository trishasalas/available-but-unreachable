# Code-review subset of the anonymous supplement

This smaller package is intended for code inspection under a 30 MB upload limit.
All source code, notebooks, stimuli, summary tables, and registered-ablation
artifacts from the full supplement are retained. The detailed per-head/layer
accessibility CSVs under results/effective_binding/ are omitted for size.
Analysis code that reads those raw CSVs needs the full supplement to run; this
subset alone cannot reproduce the effective-binding analyses from their raw inputs.

CODE_REVIEW_PACKAGE.json lists every omitted file and its original packaged hash,
and identifies the full source ZIP by SHA-256. All retained files are byte-identical
to that ZIP except this README and the regenerated SHA256SUMS.json. ANONYMIZATION.json
is retained as the historical provenance map for the full supplement, including
entries for omitted files. SHA256SUMS.json covers the files actually included here.

The original full-supplement README follows; its descriptions of raw binding data
availability apply only to the full supplement.

---

# Anonymous reproducibility supplement

This package accompanies the manuscript. It contains frozen stimuli, saved results,
analysis code, inference notebooks, and provenance records. The manuscript appendix
is the guide to the reported estimands. Other domains in the shared inventories are
not evidence for cross-domain generalization; older result tables are not substitutes
for the canonical tables named below. No model weights are included.

## Main evidence

- Behavioral means: results/analysis/{pythia,gpt2,olmo}_gap.csv.
- Paired test: results/analysis/paired_gap_{cells,summary}.csv and paired_item_coded.csv.
- Raw binding versus accuracy: results/analysis/binding_accuracy_corr.csv.
- Value-weighted binding: results/analysis/effective_binding_correlations_{natural,uniform}.csv
  and effective_binding_aggregate_permutation_{natural,uniform}.csv.
- Declarative frequency: results/frequency/spearman_summary.csv, all_rows only;
  spearman_partial.csv for declarative sensitivity. spearman_accuracy.csv is historical.
- Registered intervention: results/ablation/frequency_heads/pythia-2.8b/*registered-*.

Read src/effective_binding_inputs.py before loading effective-binding inputs: it
resolves the saved GPT-2-large natural/uniform label reversal. GPT-2-medium uniform
is the verified rerun. Do not silently treat filenames alone as condition truth.
The shared Pile binding predictor differs from family-matched declarative predictors.
There is no new statistical token-count control for value-weighted binding.

## Running analyses

Use Python with numpy, pandas, scipy, PyYAML and matplotlib for saved-data analyses.
Inference additionally requires the model libraries; requirements.txt is a broad
development dependency list, not an exact reconstruction of every historical run.
Run manifests record available versions, checkpoints and hardware. Missing revisions
are not retrospectively filled. Inference notebooks may incur substantial compute.
Open notebooks from the unpacked notebooks directory. Personal clone and publishing
cells were replaced or omitted. Do not run the effective-binding analysis notebook's
head-selection cells over the registered frozen selection artifacts: those artifacts
are part of the intervention's provenance, not outputs to refresh for publication.

## Anonymization and hash provenance

Original repository files were not modified. Notebook outputs and metadata were
cleared; personal repository setup/publishing cells were removed or replaced. Identity
comments and personal local paths were anonymized. Scientific result CSVs are copied
unchanged. ANONYMIZATION.json maps original and packaged SHA-256 values and records
each transformation. SHA256SUMS.json verifies the contents of this package.

The registered saved-artifact audit passed all eleven original hashes in the source
repository. Its historical manifest retains those original hashes. The anonymous
frequency-head-ablation notebook has a different hash because its personal setup and
publishing cells were removed; running the original checker unchanged will stop at
that notebook hash. This package does not claim that its anonymous notebook bytes
reproduce the original notebook hash. Result statistics and frozen splits are intact.
Full baseline/intervened vocabulary distributions were not saved, so KL cannot be
independently reconstructed from CSVs alone.

The ZIP contains no Git history, credentials, manuscript author metadata, or links to
a named copy of this manuscript. The exact prompt inventory is prompt-inventory.md.


For a complete saved-data check in this anonymous package, run
`python verify-registered-anonymous.py` from the unpacked root. This separately
named derivative checks the ten unchanged original hashes and the anonymous
notebook's packaged hash. It explicitly reports the notebook exception before
recomputing selection, random controls and statistical tests. It does not claim
independent reproduction of the original notebook hash. The historical checker
under docs/audits/ is retained unchanged.
